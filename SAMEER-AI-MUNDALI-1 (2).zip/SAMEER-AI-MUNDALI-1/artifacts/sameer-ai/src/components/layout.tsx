import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@workspace/replit-auth-web";
import { 
  useListOpenaiConversations, 
  useDeleteOpenaiConversation,
  useCreateOpenaiConversation
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { 
  MessageSquare, Plus, Image as ImageIcon, Film,
  LogOut, Sun, Moon, Trash2, Menu, X, BrainCircuit, Search, Instagram
} from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [location, setLocation] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: conversations = [], isLoading: convsLoading } = useListOpenaiConversations();
  const deleteMutation = useDeleteOpenaiConversation();
  const createMutation = useCreateOpenaiConversation();
  const queryClient = useQueryClient();

  const handleNewChat = async () => {
    try {
      const newConv = await createMutation.mutateAsync({ data: { title: "New Conversation" } });
      queryClient.invalidateQueries({ queryKey: ["/api/openai/conversations"] });
      setLocation(`/chat/${newConv.id}`);
      setIsMobileMenuOpen(false);
    } catch (e) {
      console.error("Failed to create conversation", e);
    }
  };

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Delete this conversation?")) {
      await deleteMutation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: ["/api/openai/conversations"] });
      if (location === `/chat/${id}`) {
        setLocation('/chat');
      }
    }
  };

  const filteredConversations = conversations.filter(c => 
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-card/50 backdrop-blur-xl border-r border-border/50">
      <div className="p-4 flex items-center gap-3 border-b border-border/50">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/20">
          <BrainCircuit className="w-5 h-5 text-white" />
        </div>
        <h1 className="font-display font-bold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/70">
          SAMEER AI
        </h1>
      </div>

      <div className="p-3">
        <button
          onClick={handleNewChat}
          disabled={createMutation.isPending}
          className="w-full flex items-center gap-2 px-4 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/25 transition-all active:scale-[0.98] disabled:opacity-50"
        >
          <Plus className="w-5 h-5" />
          {createMutation.isPending ? "Creating..." : "New Chat"}
        </button>
      </div>

      <div className="px-3 pb-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search chats..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-background/50 border border-border rounded-lg pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-2 mb-2">
          Conversations
        </div>
        {convsLoading ? (
          <div className="animate-pulse space-y-2 px-2">
            {[1, 2, 3].map(i => <div key={i} className="h-10 bg-muted rounded-lg" />)}
          </div>
        ) : filteredConversations.length === 0 ? (
          <div className="text-sm text-muted-foreground px-2 py-4 text-center">
            No chats found
          </div>
        ) : (
          filteredConversations.map(conv => {
            const isActive = location === `/chat/${conv.id}`;
            return (
              <Link key={conv.id} href={`/chat/${conv.id}`} className={cn(
                "group flex items-center justify-between px-3 py-2.5 rounded-lg transition-all text-sm",
                isActive 
                  ? "bg-primary/10 text-primary font-medium" 
                  : "text-foreground/80 hover:bg-muted/80 hover:text-foreground"
              )} onClick={() => setIsMobileMenuOpen(false)}>
                <div className="flex items-center gap-3 overflow-hidden">
                  <MessageSquare className={cn("w-4 h-4 shrink-0", isActive ? "text-primary" : "text-muted-foreground")} />
                  <span className="truncate">{conv.title}</span>
                </div>
                <button
                  onClick={(e) => handleDelete(e, conv.id)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:bg-destructive/10 hover:text-destructive rounded transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </Link>
            );
          })
        )}
      </div>

      <div className="p-3 border-t border-border/50 space-y-1">
        <Link href="/image-gen" className={cn(
          "flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm font-medium",
          location === "/image-gen" ? "bg-primary/10 text-primary" : "text-foreground/80 hover:bg-muted"
        )} onClick={() => setIsMobileMenuOpen(false)}>
          <ImageIcon className="w-4 h-4" /> Image Generation
        </Link>
        <Link href="/video-gen" className={cn(
          "flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm font-medium",
          location === "/video-gen" ? "bg-primary/10 text-primary" : "text-foreground/80 hover:bg-muted"
        )} onClick={() => setIsMobileMenuOpen(false)}>
          <Film className="w-4 h-4" /> AI Video Generator
        </Link>
        <button
          onClick={toggleTheme}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm font-medium text-foreground/80 hover:bg-muted"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
        </button>
      </div>

      <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/30">
        <div className="flex items-center gap-3 overflow-hidden">
          <img 
            src={user?.profileImageUrl || `https://ui-avatars.com/api/?name=${user?.firstName || 'User'}&background=random`} 
            alt="Profile" 
            className="w-9 h-9 rounded-full border border-border"
          />
          <div className="flex flex-col overflow-hidden">
            <span className="text-sm font-medium truncate text-foreground">{user?.firstName} {user?.lastName}</span>
            <span className="text-xs text-muted-foreground truncate">{user?.email}</span>
          </div>
        </div>
        <button onClick={logout} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
          <LogOut className="w-4 h-4" />
        </button>
      </div>

      <div className="px-4 pb-3">
        <a
          href="https://www.instagram.com/sameer_sss_rajput?igsh=OHJkODZhcWFvZm9j"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-xs text-muted-foreground hover:text-pink-500 transition-colors group"
        >
          <Instagram className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
          <span>DEVELOPER BY SAMEER</span>
        </a>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden selection:bg-primary/30">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-72 h-full shrink-0">
        <SidebarContent />
      </div>

      {/* Mobile Header & Menu */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-background/80 backdrop-blur-md border-b border-border/50 z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-6 h-6 text-primary" />
          <span className="font-display font-bold">SAMEER AI</span>
        </div>
        <button onClick={() => setIsMobileMenuOpen(true)} className="p-2">
          <Menu className="w-6 h-6" />
        </button>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 md:hidden"
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", bounce: 0, duration: 0.4 }}
              className="fixed inset-y-0 left-0 w-80 bg-background z-50 md:hidden shadow-2xl"
            >
              <button 
                onClick={() => setIsMobileMenuOpen(false)}
                className="absolute top-4 right-4 p-2 bg-muted rounded-full z-50"
              >
                <X className="w-5 h-5" />
              </button>
              <SidebarContent />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative pt-14 md:pt-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none -z-10" />
        {children}
      </div>
    </div>
  );
}
