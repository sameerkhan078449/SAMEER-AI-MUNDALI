import { useAuth } from "@workspace/replit-auth-web";
import { BrainCircuit, Sparkles, Code2, Image as ImageIcon, Zap, Shield, Instagram } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect, useRef } from "react";

export default function Landing() {
  const { login } = useAuth();
  const baseUrl = import.meta.env.BASE_URL.replace(/\/$/, "");
  const hasPlayedRef = useRef(false);

  useEffect(() => {
    if (hasPlayedRef.current) return;
    hasPlayedRef.current = true;

    const playWelcome = async () => {
      try {
        const res = await fetch(`${baseUrl}/api/openai/tts`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ text: "Welcome to SAMEER AI", voice: "nova" }),
        });
        if (!res.ok) return;
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audio.volume = 0.85;
        await audio.play();
        audio.onended = () => URL.revokeObjectURL(url);
      } catch (err) {
        console.log("Welcome voice skipped:", err);
      }
    };

    const timer = setTimeout(playWelcome, 800);
    return () => clearTimeout(timer);
  }, []);

  const features = [
    { icon: Sparkles, title: "Advanced AI Chat", desc: "Real-time streaming responses with unmatched intelligence." },
    { icon: Code2, title: "Code Execution", desc: "Write, analyze, and execute code within your conversation." },
    { icon: ImageIcon, title: "Image Generation", desc: "Create stunning 4K visuals directly from your thoughts." },
    { icon: Zap, title: "Lightning Fast", desc: "Optimized infrastructure for zero-latency interactions." },
    { icon: BrainCircuit, title: "Context Memory", desc: "Remembers past interactions for truly personalized chat." },
    { icon: Shield, title: "Enterprise Security", desc: "Your data is encrypted and completely private." },
  ];

  return (
    <div className="min-h-screen bg-background relative overflow-hidden flex flex-col">
      <div className="absolute inset-0 z-0 opacity-40 dark:opacity-20 mix-blend-screen">
        <img
          src={`${baseUrl}/images/hero-bg.png`}
          alt="Hero Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      </div>

      <nav className="relative z-10 px-6 py-6 flex items-center justify-between max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-lg shadow-primary/25">
            <BrainCircuit className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight text-foreground">SAMEER AI MUNDALI</span>
        </div>
        <button
          onClick={login}
          className="px-6 py-2.5 rounded-full font-medium text-sm bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
        >
          Sign In
        </button>
      </nav>

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 pt-12 pb-24 text-center max-w-5xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary mb-8 text-sm font-medium"
        >
          <Sparkles className="w-4 h-4" />
          <span>The Next Generation of AI is Here</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-5xl md:text-7xl font-bold tracking-tight text-foreground leading-[1.1] mb-6"
        >
          Your Ultimate <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-blue-400">
            Intelligent Assistant
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10"
        >
          Experience real-time AI conversations, 4K image generation, voice interaction, and advanced code analysis in one premium platform.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center gap-4"
        >
          <button
            onClick={login}
            className="px-8 py-4 rounded-full font-semibold text-lg bg-gradient-to-r from-primary to-accent text-white shadow-xl shadow-primary/30 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300"
          >
            Get Started Free
          </button>
          <button className="px-8 py-4 rounded-full font-semibold text-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-all duration-300">
            View Features
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-24 w-full"
        >
          {features.map((feat, i) => (
            <div key={i} className="bg-card/50 backdrop-blur-lg border border-border/50 rounded-2xl p-6 text-left hover:bg-card/80 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 text-primary">
                <feat.icon className="w-6 h-6" />
              </div>
              <h3 className="font-semibold text-lg mb-2 text-foreground">{feat.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </motion.div>
      </main>

      <footer className="relative z-10 py-6 px-6 border-t border-border/30">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm text-muted-foreground">
            © 2024 SAMEER AI MUNDALI. All rights reserved.
          </p>
          <a
            href="https://www.instagram.com/sameer_sss_rajput?igsh=OHJkODZhcWFvZm9j"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-500/20 text-pink-500 hover:from-pink-500/20 hover:to-purple-500/20 transition-all text-sm font-medium group"
          >
            <Instagram className="w-4 h-4 group-hover:scale-110 transition-transform" />
            <span>DEVELOPER BY SAMEER</span>
          </a>
        </div>
      </footer>
    </div>
  );
}
