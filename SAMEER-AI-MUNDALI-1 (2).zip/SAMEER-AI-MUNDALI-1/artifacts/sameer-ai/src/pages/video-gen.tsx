import { useState, useRef } from "react";
import { Film, Sparkles, Download, RefreshCw, ChevronLeft, ChevronRight, Play, Pause, Wand2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const VIDEO_STYLES = [
  { id: "anime", label: "🎌 Anime", desc: "Manga / Studio Ghibli style" },
  { id: "realistic", label: "📸 Realistic", desc: "Cinematic photorealistic" },
  { id: "cartoon", label: "🎨 Cartoon", desc: "Pixar / animated fun" },
  { id: "fantasy", label: "✨ Fantasy", desc: "Epic magical art" },
  { id: "cinematic", label: "🎬 Cinematic", desc: "Movie-quality scenes" },
];

const FRAME_OPTIONS = [4, 6, 8];

interface Frame {
  index: number;
  b64_json: string;
  description: string;
}

export default function VideoGen() {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("anime");
  const [frameCount, setFrameCount] = useState(6);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [frames, setFrames] = useState<Frame[]>([]);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");
  const playIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const generate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setFrames([]);
    setProgress(0);
    setTotal(0);
    setCurrentFrame(0);
    setIsPlaying(false);
    setIsGenerating(true);
    setStatusMsg("Writing video script with AI...");

    try {
      const res = await fetch(`${BASE}/api/openai/generate-video-frames`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ prompt, style, frameCount }),
      });

      if (!res.ok || !res.body) throw new Error("Failed to start video generation");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.type === "script") {
              setTotal(data.total);
              setStatusMsg(`Generating ${data.total} AI video frames...`);
            } else if (data.type === "frame") {
              setProgress(data.index + 1);
              setStatusMsg(`Rendering frame ${data.index + 1} of ${data.total}...`);
              setFrames(prev => [...prev, { index: data.index, b64_json: data.b64_json, description: data.description }]);
            } else if (data.type === "done") {
              setStatusMsg("Video ready!");
            } else if (data.type === "error") {
              setStatusMsg("Error generating video. Please try again.");
            }
          } catch {}
        }
      }
    } catch (err) {
      console.error("Video gen error:", err);
      setStatusMsg("Generation failed. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const togglePlay = () => {
    if (frames.length === 0) return;
    if (isPlaying) {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      playIntervalRef.current = setInterval(() => {
        setCurrentFrame(f => {
          if (f >= frames.length - 1) { clearInterval(playIntervalRef.current!); setIsPlaying(false); return 0; }
          return f + 1;
        });
      }, 800);
    }
  };

  const downloadFrame = (frame: Frame) => {
    const a = document.createElement("a");
    a.href = `data:image/png;base64,${frame.b64_json}`;
    a.download = `sameer-ai-video-frame-${frame.index + 1}.png`;
    a.click();
  };

  const downloadAll = () => {
    frames.forEach((f, i) => {
      setTimeout(() => downloadFrame(f), i * 300);
    });
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      <header className="h-14 shrink-0 px-6 flex items-center gap-3 bg-background/80 backdrop-blur-md border-b border-border/50 sticky top-0 z-10">
        <Film className="w-5 h-5 text-primary" />
        <h2 className="font-semibold text-foreground">AI Video Generator</h2>
        <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">SAMEER AI</span>
      </header>

      <div className="flex-1 max-w-5xl mx-auto w-full px-4 py-8 space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
            AI Video Generation
          </h1>
          <p className="text-muted-foreground">
            AI se apni story batao — frames khud generate honge. Anime, Realistic, Cartoon — koi bhi style!
          </p>
        </div>

        <div className="bg-card border border-border/50 rounded-2xl p-6 space-y-6 shadow-lg shadow-primary/5">
          <div>
            <label className="block text-sm font-semibold mb-2 text-foreground">Video ka idea / story likho</label>
            <textarea
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="Jaise: A brave samurai walks through a magical cherry blossom forest at sunset..."
              className="w-full bg-background/50 border border-border rounded-xl px-4 py-3 text-sm resize-none outline-none focus:ring-2 focus:ring-primary/30 min-h-[100px] text-foreground placeholder:text-muted-foreground"
              rows={3}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-3 text-foreground">Video Style</label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {VIDEO_STYLES.map(s => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={cn(
                    "flex flex-col items-center gap-1 p-3 rounded-xl border text-center transition-all text-sm",
                    style === s.id
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border/50 hover:border-primary/30 hover:bg-muted text-foreground/80"
                  )}
                >
                  <span className="text-lg">{s.label.split(" ")[0]}</span>
                  <span className="font-medium text-xs">{s.label.split(" ").slice(1).join(" ")}</span>
                  <span className="text-xs text-muted-foreground leading-tight">{s.desc}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-3 text-foreground">Frames (video length)</label>
            <div className="flex gap-3">
              {FRAME_OPTIONS.map(n => (
                <button
                  key={n}
                  onClick={() => setFrameCount(n)}
                  className={cn(
                    "px-5 py-2.5 rounded-xl border text-sm font-medium transition-all",
                    frameCount === n
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border/50 hover:border-primary/30 text-foreground/80 hover:bg-muted"
                  )}
                >
                  {n} frames
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generate}
            disabled={!prompt.trim() || isGenerating}
            className="w-full flex items-center justify-center gap-3 py-4 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-semibold text-base hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-[0.99] shadow-xl shadow-primary/25"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>{statusMsg}</span>
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                <span>Generate AI Video</span>
              </>
            )}
          </button>

          {isGenerating && total > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Generating frames...</span>
                <span>{progress}/{total}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                  animate={{ width: `${(progress / total) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          )}
        </div>

        <AnimatePresence>
          {frames.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border/50 rounded-2xl p-6 shadow-lg"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <Film className="w-5 h-5 text-primary" />
                  Generated Video ({frames.length} frames)
                </h3>
                <div className="flex items-center gap-2">
                  <button
                    onClick={downloadAll}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm border border-border/50 hover:bg-muted transition-colors text-foreground/80"
                  >
                    <Download className="w-4 h-4" />
                    Download All
                  </button>
                </div>
              </div>

              <div className="relative aspect-video bg-black rounded-xl overflow-hidden mb-4 shadow-2xl">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={currentFrame}
                    src={`data:image/png;base64,${frames[currentFrame]?.b64_json}`}
                    alt={`Frame ${currentFrame + 1}`}
                    className="w-full h-full object-cover"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  />
                </AnimatePresence>
                <div className="absolute bottom-3 left-3 right-3 flex items-center gap-3">
                  <div className="flex-1 bg-black/50 backdrop-blur rounded-full h-1 overflow-hidden">
                    <div
                      className="h-full bg-white rounded-full transition-all duration-300"
                      style={{ width: `${((currentFrame + 1) / frames.length) * 100}%` }}
                    />
                  </div>
                  <span className="text-white text-xs font-medium bg-black/50 px-2 py-0.5 rounded-full">
                    {currentFrame + 1}/{frames.length}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4 mb-4">
                <button
                  onClick={() => { setCurrentFrame(f => Math.max(0, f - 1)); setIsPlaying(false); }}
                  disabled={currentFrame === 0}
                  className="p-2 rounded-xl border border-border/50 hover:bg-muted disabled:opacity-30 transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={togglePlay}
                  className="p-3 rounded-xl bg-primary text-white hover:bg-primary/90 transition-colors shadow-lg shadow-primary/25"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </button>
                <button
                  onClick={() => { setCurrentFrame(f => Math.min(frames.length - 1, f + 1)); setIsPlaying(false); }}
                  disabled={currentFrame === frames.length - 1}
                  className="p-2 rounded-xl border border-border/50 hover:bg-muted disabled:opacity-30 transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              <div className="text-sm text-muted-foreground text-center italic px-4">
                {frames[currentFrame]?.description}
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mt-4">
                {frames.map((f, i) => (
                  <button
                    key={i}
                    onClick={() => { setCurrentFrame(i); setIsPlaying(false); }}
                    className={cn(
                      "relative aspect-video rounded-lg overflow-hidden border-2 transition-all",
                      i === currentFrame ? "border-primary scale-105 shadow-lg shadow-primary/20" : "border-border/30 hover:border-primary/40"
                    )}
                  >
                    <img src={`data:image/png;base64,${f.b64_json}`} alt={`Frame ${i + 1}`} className="w-full h-full object-cover" />
                    <div className="absolute bottom-0.5 right-0.5 text-xs bg-black/60 text-white px-1 rounded">{i + 1}</div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="text-center text-xs text-muted-foreground pb-8">
          SAMEER AI Video Generator · Built by Sameer from Mundali, Meerut ·
          <a href="https://www.instagram.com/sameer_sss_rajput?igsh=OHJkODZhcWFvZm9j" target="_blank" rel="noopener noreferrer" className="text-pink-500 ml-1 hover:underline">@sameer_sss_rajput</a>
        </div>
      </div>
    </div>
  );
}
