import { useState } from "react";
import { useGenerateOpenaiImage } from "@workspace/api-client-react";
import { Sparkles, Image as ImageIcon, Download, Loader2, Wand2 } from "lucide-react";
import { motion } from "framer-motion";

export default function ImageGen() {
  const [prompt, setPrompt] = useState("");
  const mutation = useGenerateOpenaiImage();

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    mutation.mutate({ data: { prompt, size: "1024x1024" } });
  };

  const handleDownload = () => {
    if (!mutation.data?.b64_json) return;
    const link = document.createElement("a");
    link.href = `data:image/png;base64,${mutation.data.b64_json}`;
    link.download = `sameer-ai-image-${Date.now()}.png`;
    link.click();
  };

  return (
    <div className="flex flex-col h-full bg-background overflow-y-auto">
      <div className="max-w-5xl mx-auto w-full px-6 py-10">
        
        <div className="mb-10 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mx-auto mb-4">
            <ImageIcon className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl font-display font-bold mb-3 text-foreground tracking-tight">AI Image Generation</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Describe what you want to see, and SAMEER AI will generate a beautiful, high-resolution 4k image for you in seconds.
          </p>
        </div>

        <form onSubmit={handleGenerate} className="mb-12 relative max-w-3xl mx-auto">
          <div className="glass-panel rounded-2xl p-2 flex gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A futuristic cyber-city during sunset, glowing neon lights, cinematic lighting..."
              className="flex-1 bg-transparent border-0 px-4 py-3 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-0"
              disabled={mutation.isPending}
            />
            <button
              type="submit"
              disabled={!prompt.trim() || mutation.isPending}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-medium shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/35 transition-all disabled:opacity-50 flex items-center gap-2"
            >
              {mutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Wand2 className="w-5 h-5" />}
              {mutation.isPending ? "Generating..." : "Generate"}
            </button>
          </div>
        </form>

        <div className="min-h-[400px] flex items-center justify-center border-2 border-dashed border-border/50 rounded-3xl bg-card/30 relative overflow-hidden">
          {mutation.isPending ? (
            <div className="flex flex-col items-center text-primary">
              <Loader2 className="w-12 h-12 animate-spin mb-4" />
              <p className="font-medium animate-pulse">Dreaming up your image...</p>
            </div>
          ) : mutation.data?.b64_json ? (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full h-full relative group"
            >
              <img 
                src={`data:image/png;base64,${mutation.data.b64_json}`} 
                alt={prompt}
                className="w-full h-auto object-cover rounded-3xl"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm rounded-3xl">
                <button 
                  onClick={handleDownload}
                  className="px-6 py-3 rounded-xl bg-white text-black font-semibold flex items-center gap-2 hover:scale-105 transition-transform"
                >
                  <Download className="w-5 h-5" /> Download HD
                </button>
              </div>
            </motion.div>
          ) : mutation.isError ? (
            <div className="text-destructive text-center">
              <p className="font-medium text-lg mb-2">Generation Failed</p>
              <p className="text-sm opacity-80">Please try a different prompt or try again later.</p>
            </div>
          ) : (
            <div className="text-muted-foreground text-center flex flex-col items-center">
              <Sparkles className="w-10 h-10 mb-3 opacity-50" />
              <p>Your creation will appear here</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
