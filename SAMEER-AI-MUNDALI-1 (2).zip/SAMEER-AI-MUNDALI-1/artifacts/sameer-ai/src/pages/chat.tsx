import { useState, useRef, useEffect, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import {
  useGetOpenaiConversation,
  useListOpenaiMessages,
  useCreateOpenaiConversation,
  useUpdateOpenaiConversation,
} from "@workspace/api-client-react";
import { useChatStream } from "@/hooks/use-chat-stream";
import { MarkdownRenderer } from "@/components/markdown-renderer";
import {
  Send, Bot, User, Paperclip, Mic, MicOff, Image as ImageIcon,
  SquareTerminal, Sparkles, Loader2, Copy, Check, RefreshCw,
  Volume2, VolumeX, X, FileText, Film
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation as useWouterLocation } from "wouter";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

const SUGGESTIONS = [
  { icon: "💻", text: "Write a Python script to sort a list" },
  { icon: "🎨", text: "Generate a beautiful sunset image" },
  { icon: "🧠", text: "Explain quantum computing simply" },
  { icon: "📝", text: "Write a professional email for me" },
  { icon: "🔧", text: "Help me debug my React code" },
  { icon: "🌍", text: "Translate this text to Hindi" },
  { icon: "📊", text: "Create a business plan outline" },
  { icon: "🎵", text: "Write song lyrics about friendship" },
];

export default function Chat() {
  const params = useParams();
  const conversationId = params.id ? parseInt(params.id, 10) : undefined;
  const [, setLocation] = useLocation();

  const { data: conversation } = useGetOpenaiConversation(conversationId as number, { query: { enabled: !!conversationId } });
  const { data: messages = [], isLoading: messagesLoading } = useListOpenaiMessages(conversationId as number, { query: { enabled: !!conversationId } });

  const createMutation = useCreateOpenaiConversation();
  const updateMutation = useUpdateOpenaiConversation();
  const queryClient = useQueryClient();

  const [input, setInput] = useState("");
  const [mode, setMode] = useState<"chat" | "code" | "qa">("chat");
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [fileText, setFileText] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [voiceOutput, setVoiceOutput] = useState(true);
  const [recordingTime, setRecordingTime] = useState(0);

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const { sendMessage, isStreaming, streamingContent } = useChatStream({
    conversationId: conversationId || 0,
    onFinish: async (fullText) => {
      if (voiceOutput && fullText && fullText.length < 800) {
        const shortText = fullText.replace(/```[\s\S]*?```/g, "").slice(0, 400);
        if (shortText.trim()) speakText(shortText.trim());
      }
    },
  });

  const speakText = async (text: string) => {
    try {
      const res = await fetch(`${BASE}/api/openai/tts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ text, voice: "nova" }),
      });
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.play();
      audio.onended = () => URL.revokeObjectURL(url);
    } catch (e) {
      console.log("TTS error:", e);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    }
  }, [messages, streamingContent]);

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = `${Math.min(e.target.scrollHeight, 220)}px`;
  };

  const handleSend = async () => {
    if ((!input.trim() && !imageBase64 && !fileText) || isStreaming) return;
    let content = input.trim();
    if (fileText) content = `${content}\n\n[File: ${fileName}]\n${fileText}`;
    const img = imageBase64 || undefined;

    setInput("");
    setImageBase64(null);
    setImagePreview(null);
    setFileText(null);
    setFileName(null);
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    if (!conversationId) {
      try {
        const title = content.slice(0, 40) || "New Chat";
        const newConv = await createMutation.mutateAsync({ data: { title } });
        sessionStorage.setItem("pending_chat_msg", JSON.stringify({ content, img, mode }));
        setLocation(`/chat/${newConv.id}`);
      } catch (err) {
        console.error("Failed to create conversation", err);
      }
      return;
    }

    sendMessage(content, mode, img);

    if (messages.length === 0 && conversationId && content) {
      setTimeout(async () => {
        try {
          await updateMutation.mutateAsync({ id: conversationId, data: { title: content.slice(0, 40) } });
          queryClient.invalidateQueries({ queryKey: ["/api/openai/conversations"] });
        } catch {}
      }, 2000);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  useEffect(() => {
    if (conversationId) {
      const pending = sessionStorage.getItem("pending_chat_msg");
      if (pending) {
        sessionStorage.removeItem("pending_chat_msg");
        try {
          const { content, img, mode: m } = JSON.parse(pending);
          if (content) sendMessage(content, m || "chat", img);
        } catch {}
      }
    }
  }, [conversationId]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(",")[1];
      setImageBase64(base64);
      setImagePreview(result);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);

    if (file.type === "text/plain" || file.name.endsWith(".txt") || file.name.endsWith(".md")) {
      const text = await file.text();
      setFileText(text.slice(0, 8000));
    } else if (file.type === "application/pdf") {
      setFileText("[PDF uploaded - content will be processed]");
    } else {
      const text = await file.text();
      setFileText(text.slice(0, 8000));
    }
    e.target.value = "";
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
      const mr = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = mr;
      mr.ondataavailable = (e) => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const b64 = (reader.result as string).split(",")[1];
          if (!conversationId) return;
          try {
            const res = await fetch(`${BASE}/api/openai/conversations/${conversationId}/voice-messages`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              credentials: "include",
              body: JSON.stringify({ audio: b64 }),
            });
            if (res.ok && res.body) {
              const reader2 = res.body.getReader();
              const dec = new TextDecoder();
              let buf = "";
              while (true) {
                const { value, done } = await reader2.read();
                if (done) break;
                buf += dec.decode(value, { stream: true });
                const lines = buf.split("\n");
                buf = lines.pop() || "";
                for (const line of lines) {
                  if (line.startsWith("data: ")) {
                    try {
                      const d = JSON.parse(line.slice(6));
                      if (d.type === "audio" && d.data) {
                        const ab = Uint8Array.from(atob(d.data), c => c.charCodeAt(0));
                        const aBlob = new Blob([ab], { type: "audio/mpeg" });
                        const url = URL.createObjectURL(aBlob);
                        const audio = new Audio(url);
                        audio.play();
                        audio.onended = () => URL.revokeObjectURL(url);
                      }
                    } catch {}
                  }
                }
              }
              queryClient.invalidateQueries({ queryKey: [`/api/openai/conversations/${conversationId}/messages`] });
            }
          } catch (err) {
            console.error("Voice message error:", err);
          }
        };
        reader.readAsDataURL(blob);
      };
      mr.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingTimerRef.current = setInterval(() => setRecordingTime(t => t + 1), 1000);
    } catch (err) {
      alert("Microphone access denied. Please allow microphone access.");
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
    if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
  };

  const isEmpty = !conversationId || messages.length === 0;

  return (
    <div className="flex flex-col h-full relative">
      {conversationId && (
        <header className="h-14 shrink-0 px-6 items-center justify-between bg-background/80 backdrop-blur-md border-b border-border/50 z-10 hidden md:flex">
          <h2 className="font-semibold text-foreground/90 truncate max-w-[600px]">{conversation?.title || "Chat"}</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setVoiceOutput(v => !v)}
              className={cn("p-2 rounded-lg transition-colors text-sm flex items-center gap-1.5", voiceOutput ? "text-primary bg-primary/10" : "text-muted-foreground hover:bg-muted")}
              title={voiceOutput ? "Voice output on" : "Voice output off"}
            >
              {voiceOutput ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span className="text-xs hidden lg:block">{voiceOutput ? "Voice On" : "Voice Off"}</span>
            </button>
          </div>
        </header>
      )}

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-6 scroll-smooth">
        <div className="max-w-4xl mx-auto space-y-6">
          {isEmpty && !isStreaming ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center min-h-[50vh] text-center px-4"
            >
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center mb-6 shadow-lg shadow-primary/10">
                <Sparkles className="w-10 h-10 text-primary" />
              </div>
              <h1 className="text-3xl font-bold mb-3 text-foreground">Main kya kar sakta hun?</h1>
              <p className="text-muted-foreground max-w-md mx-auto mb-8 text-base">
                Main SAMEER AI hun — coding, images, translation, Q&A, ya kuch bhi — bas poochho!
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-3xl">
                {SUGGESTIONS.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => { setInput(s.text); textareaRef.current?.focus(); }}
                    className="p-3.5 rounded-xl border border-border/50 bg-card/50 hover:bg-muted/50 hover:border-primary/30 text-left transition-all text-sm text-foreground/80 hover:text-foreground flex flex-col gap-1.5"
                  >
                    <span className="text-xl">{s.icon}</span>
                    <span className="leading-tight">{s.text}</span>
                  </button>
                ))}
              </div>
              <div className="mt-8 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5"><Film className="w-4 h-4 text-primary" /> AI Video</span>
                <span className="flex items-center gap-1.5"><ImageIcon className="w-4 h-4 text-primary" /> Image Gen</span>
                <span className="flex items-center gap-1.5"><Mic className="w-4 h-4 text-primary" /> Voice Chat</span>
                <span className="flex items-center gap-1.5"><FileText className="w-4 h-4 text-primary" /> File Upload</span>
              </div>
            </motion.div>
          ) : (
            <>
              {messages.map((msg) => (
                <MessageBubble key={msg.id} role={msg.role as "user" | "assistant"} content={msg.content} onSpeak={speakText} />
              ))}
              {isStreaming && <MessageBubble role="assistant" content={streamingContent} isStreaming onSpeak={speakText} />}
              {messagesLoading && (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-6 h-6 animate-spin text-primary" />
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="shrink-0 px-4 pb-4 bg-gradient-to-t from-background via-background/95 to-transparent pt-6">
        <div className="max-w-4xl mx-auto">
          <AnimatePresence>
            {(imagePreview || fileName) && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="flex gap-2 mb-2 flex-wrap"
              >
                {imagePreview && (
                  <div className="relative group">
                    <img src={imagePreview} className="h-16 w-16 object-cover rounded-xl border border-border" alt="preview" />
                    <button onClick={() => { setImageBase64(null); setImagePreview(null); }} className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-destructive rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <X className="w-3 h-3 text-white" />
                    </button>
                  </div>
                )}
                {fileName && (
                  <div className="relative group flex items-center gap-2 px-3 py-2 bg-muted rounded-xl border border-border text-sm">
                    <FileText className="w-4 h-4 text-primary" />
                    <span className="max-w-[120px] truncate">{fileName}</span>
                    <button onClick={() => { setFileText(null); setFileName(null); }} className="ml-1 text-muted-foreground hover:text-destructive">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="rounded-2xl border border-border/60 bg-card/80 backdrop-blur-xl shadow-2xl shadow-primary/5 flex flex-col overflow-hidden">
            <div className="flex items-center gap-1 px-3 pt-2.5 pb-1.5 border-b border-border/30">
              <ModeButton mode={mode} id="chat" setMode={setMode} icon={<Sparkles className="w-3.5 h-3.5" />} label="Chat" />
              <ModeButton mode={mode} id="code" setMode={setMode} icon={<SquareTerminal className="w-3.5 h-3.5" />} label="Code" />
              <ModeButton mode={mode} id="qa" setMode={setMode} icon={<Bot className="w-3.5 h-3.5" />} label="Q&A" />
            </div>

            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInput}
              onKeyDown={handleKeyDown}
              placeholder={isRecording ? `Recording... ${recordingTime}s (click mic to stop)` : "SAMEER AI se kuch bhi poochho..."}
              disabled={isRecording}
              className="w-full bg-transparent border-0 resize-none outline-none px-4 py-3 text-foreground placeholder:text-muted-foreground min-h-[52px] max-h-[220px] text-sm leading-relaxed"
              rows={1}
            />

            <div className="flex items-center justify-between px-3 pb-2.5 pt-1">
              <div className="flex items-center gap-1">
                <input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                <input ref={fileInputRef} type="file" accept=".txt,.md,.pdf,.js,.ts,.py,.json,.csv,.html,.css" className="hidden" onChange={handleFileUpload} />

                <ActionBtn onClick={() => imageInputRef.current?.click()} title="Upload image" disabled={isStreaming}>
                  <ImageIcon className="w-4.5 h-4.5" />
                </ActionBtn>
                <ActionBtn onClick={() => fileInputRef.current?.click()} title="Upload file" disabled={isStreaming}>
                  <Paperclip className="w-4.5 h-4.5" />
                </ActionBtn>
                <ActionBtn
                  onClick={isRecording ? stopRecording : startRecording}
                  title={isRecording ? "Stop recording" : "Voice input"}
                  active={isRecording}
                >
                  {isRecording ? <MicOff className="w-4.5 h-4.5" /> : <Mic className="w-4.5 h-4.5" />}
                </ActionBtn>
                {isRecording && (
                  <span className="text-xs text-red-500 font-medium animate-pulse ml-1">
                    ● {recordingTime}s
                  </span>
                )}
              </div>

              <button
                onClick={handleSend}
                disabled={(!input.trim() && !imageBase64 && !fileText) || isStreaming || createMutation.isPending}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-primary to-accent text-white font-medium text-sm hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95 shadow-md shadow-primary/20"
              >
                {isStreaming ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span className="hidden sm:block">{isStreaming ? "Generating..." : "Send"}</span>
              </button>
            </div>
          </div>

          <p className="text-center mt-2.5 text-xs text-muted-foreground">
            SAMEER AI · Built with ❤️ by Sameer, Mundali, Meerut · 3 Years of Hard Work
          </p>
        </div>
      </div>
    </div>
  );
}

function ActionBtn({ children, onClick, title, disabled, active }: { children: React.ReactNode; onClick: () => void; title: string; disabled?: boolean; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={cn(
        "p-2 rounded-lg transition-all disabled:opacity-40",
        active
          ? "text-red-500 bg-red-500/10 hover:bg-red-500/20"
          : "text-muted-foreground hover:text-foreground hover:bg-muted"
      )}
    >
      {children}
    </button>
  );
}

function ModeButton({ mode, id, setMode, icon, label }: { mode: string; id: string; setMode: (m: any) => void; icon: React.ReactNode; label: string }) {
  const isActive = mode === id;
  return (
    <button
      onClick={() => setMode(id)}
      className={cn(
        "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
        isActive
          ? "bg-primary/15 text-primary border border-primary/25"
          : "text-muted-foreground hover:bg-muted hover:text-foreground border border-transparent"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function MessageBubble({ role, content, isStreaming, onSpeak }: {
  role: "user" | "assistant";
  content: string;
  isStreaming?: boolean;
  onSpeak?: (t: string) => void;
}) {
  const isUser = role === "user";
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className={cn("flex gap-3", isUser ? "flex-row-reverse" : "flex-row")}
    >
      <div className={cn(
        "w-9 h-9 rounded-xl shrink-0 flex items-center justify-center shadow-sm text-sm font-bold",
        isUser
          ? "bg-gradient-to-br from-secondary to-muted text-secondary-foreground"
          : "bg-gradient-to-br from-primary to-accent text-white"
      )}>
        {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
      </div>

      <div className={cn("flex flex-col gap-1.5 max-w-[85%]", isUser ? "items-end" : "items-start")}>
        <div className={cn(
          "rounded-2xl px-4 py-3 text-sm leading-relaxed",
          isUser
            ? "bg-gradient-to-br from-primary/20 to-accent/10 text-foreground rounded-tr-sm border border-primary/20"
            : "bg-card border border-border/50 text-foreground rounded-tl-sm shadow-sm"
        )}>
          {isUser ? (
            <p className="whitespace-pre-wrap">{content}</p>
          ) : (
            <div className={cn("prose-sm max-w-none", isStreaming && "streaming-cursor")}>
              {content ? <MarkdownRenderer content={content} /> : (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:0ms]" />
                  <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:150ms]" />
                  <span className="w-2 h-2 rounded-full bg-primary animate-bounce [animation-delay:300ms]" />
                </div>
              )}
            </div>
          )}
        </div>

        {!isUser && !isStreaming && content && (
          <div className="flex items-center gap-1 opacity-0 hover:opacity-100 group-hover:opacity-100 transition-opacity ml-1">
            <button onClick={copy} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors" title="Copy">
              {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            {onSpeak && (
              <button onClick={() => onSpeak(content.slice(0, 400))} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors" title="Read aloud">
                <Volume2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
