import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@workspace/replit-auth-web";
import { Layout } from "@/components/layout";
import Landing from "@/pages/landing";
import Chat from "@/pages/chat";
import ImageGen from "@/pages/image-gen";
import VideoGen from "@/pages/video-gen";
import NotFound from "@/pages/not-found";
import { Loader2 } from "lucide-react";
import { useEffect } from "react";

const queryClient = new QueryClient();

// A simple redirect component since wouter v3 pattern
function Redirect({ to }: { to: string }) {
  const [, setLocation] = useLocation();
  useEffect(() => {
    setLocation(to);
  }, [to, setLocation]);
  return null;
}

function MainRouter() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center text-primary gap-4">
          <Loader2 className="w-10 h-10 animate-spin" />
          <p className="font-display font-medium text-lg">Loading SAMEER AI...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/">
        {isAuthenticated ? <Redirect to="/chat" /> : <Landing />}
      </Route>
      <Route path="/chat">
        {isAuthenticated ? <Layout><Chat /></Layout> : <Redirect to="/" />}
      </Route>
      <Route path="/chat/:id">
        {isAuthenticated ? <Layout><Chat /></Layout> : <Redirect to="/" />}
      </Route>
      <Route path="/image-gen">
        {isAuthenticated ? <Layout><ImageGen /></Layout> : <Redirect to="/" />}
      </Route>
      <Route path="/video-gen">
        {isAuthenticated ? <Layout><VideoGen /></Layout> : <Redirect to="/" />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <MainRouter />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
