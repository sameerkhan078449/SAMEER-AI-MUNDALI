import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { getListOpenaiMessagesQueryKey } from "@workspace/api-client-react";

interface StreamOptions {
  conversationId: number;
  onFinish?: (fullText: string) => void;
  onError?: (err: Error) => void;
}

export function useChatStream({ conversationId, onFinish, onError }: StreamOptions) {
  const queryClient = useQueryClient();
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");

  const sendMessage = async (content: string, mode: "chat" | "code" | "qa" = "chat", imageBase64?: string) => {
    setIsStreaming(true);
    setStreamingContent("");

    let fullText = "";

    try {
      const payload = { content, mode, ...(imageBase64 ? { imageBase64 } : {}) };
      const baseUrl = import.meta.env.BASE_URL.replace(/\/$/, "");
      const res = await fetch(`${baseUrl}/api/openai/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });

      if (!res.ok) throw new Error(`Failed to send message: ${res.statusText}`);

      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      if (!reader) throw new Error("No readable stream available");

      let done = false;
      while (!done) {
        const { value, done: readerDone } = await reader.read();
        if (readerDone) break;
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const dataStr = line.slice(6).trim();
            if (!dataStr) continue;
            if (dataStr === "[DONE]") { done = true; break; }
            try {
              const data = JSON.parse(dataStr);
              if (data.done) { done = true; break; }
              if (data.content) {
                fullText += data.content;
                setStreamingContent((prev) => prev + data.content);
              }
            } catch {}
          }
        }
      }
    } catch (err) {
      if (onError && err instanceof Error) onError(err);
      console.error("[ChatStream Error]", err);
    } finally {
      setIsStreaming(false);
      queryClient.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(conversationId) });
      if (onFinish) onFinish(fullText);
    }
  };

  return { sendMessage, isStreaming, streamingContent };
}
