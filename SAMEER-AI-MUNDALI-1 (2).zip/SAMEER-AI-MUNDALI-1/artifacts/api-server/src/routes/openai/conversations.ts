import { Router } from "express";
import { db } from "@workspace/db";
import { conversations, messages } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { openai } from "@workspace/integrations-openai-ai-server";
import { voiceChatStream, ensureCompatibleFormat } from "@workspace/integrations-openai-ai-server/audio";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";

const router = Router();

router.get("/conversations", async (req, res) => {
  try {
    const userId = req.user?.id;
    let result;
    if (userId) {
      result = await db
        .select()
        .from(conversations)
        .where(eq(conversations.userId, userId))
        .orderBy(desc(conversations.createdAt));
    } else {
      result = await db
        .select()
        .from(conversations)
        .orderBy(desc(conversations.createdAt))
        .limit(50);
    }
    res.json(result.map(c => ({
      id: c.id,
      title: c.title,
      createdAt: c.createdAt,
    })));
  } catch (err) {
    console.error("List conversations error:", err);
    res.status(500).json({ error: "Failed to list conversations" });
  }
});

router.post("/conversations", async (req, res) => {
  try {
    const { title } = req.body;
    if (!title) {
      res.status(400).json({ error: "title is required" });
      return;
    }
    const userId = req.user?.id ?? null;
    const [conv] = await db
      .insert(conversations)
      .values({ title, userId })
      .returning();
    res.status(201).json({
      id: conv.id,
      title: conv.title,
      createdAt: conv.createdAt,
    });
  } catch (err) {
    console.error("Create conversation error:", err);
    res.status(500).json({ error: "Failed to create conversation" });
  }
});

router.get("/conversations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [conv] = await db
      .select()
      .from(conversations)
      .where(eq(conversations.id, id));
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);
    res.json({
      id: conv.id,
      title: conv.title,
      createdAt: conv.createdAt,
      messages: msgs.map(m => ({
        id: m.id,
        conversationId: m.conversationId,
        role: m.role,
        content: m.content,
        createdAt: m.createdAt,
      })),
    });
  } catch (err) {
    console.error("Get conversation error:", err);
    res.status(500).json({ error: "Failed to get conversation" });
  }
});

router.patch("/conversations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { title } = req.body;
    if (!title) {
      res.status(400).json({ error: "title is required" });
      return;
    }
    const [conv] = await db
      .update(conversations)
      .set({ title })
      .where(eq(conversations.id, id))
      .returning();
    if (!conv) {
      res.status(404).json({ error: "Conversation not found" });
      return;
    }
    res.json({ id: conv.id, title: conv.title, createdAt: conv.createdAt });
  } catch (err) {
    console.error("Update conversation error:", err);
    res.status(500).json({ error: "Failed to update conversation" });
  }
});

router.delete("/conversations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(messages).where(eq(messages.conversationId, id));
    await db.delete(conversations).where(eq(conversations.id, id));
    res.status(204).send();
  } catch (err) {
    console.error("Delete conversation error:", err);
    res.status(500).json({ error: "Failed to delete conversation" });
  }
});

router.get("/conversations/:id/messages", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const msgs = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);
    res.json(msgs.map(m => ({
      id: m.id,
      conversationId: m.conversationId,
      role: m.role,
      content: m.content,
      createdAt: m.createdAt,
    })));
  } catch (err) {
    console.error("List messages error:", err);
    res.status(500).json({ error: "Failed to list messages" });
  }
});

router.post("/conversations/:id/messages", async (req, res) => {
  const id = parseInt(req.params.id);
  const { content, imageBase64, mode } = req.body;

  if (!content) {
    res.status(400).json({ error: "content is required" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const existingMessages = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(messages.createdAt);

    const aboutSameer = `
About your creator: You were created by SAMEER — a young 18-year-old developer from Mundali village, Meerut. Sameer is an incredibly talented and dedicated person who has been working on building his own AI system for 3 years. His best friend Mohd Shad has been by his side, supporting and helping him throughout this journey. Sameer is a very kind-hearted and good human being who poured his heart and soul into building you. When anyone asks who you are, who made you, or anything about your creator, tell them this story proudly. You can find Sameer on Instagram at: https://www.instagram.com/sameer_sss_rajput
`.trim();

    const systemPrompt = mode === "code"
      ? `You are SAMEER AI MUNDALI, an expert coding assistant — like a senior software engineer combined with ChatGPT's intelligence. ${aboutSameer}

CAPABILITIES: You can write, debug, explain, and optimize code in ANY language (Python, JavaScript, TypeScript, Java, C++, Rust, Go, SQL, HTML/CSS, React, Node.js, and more).

RULES:
- Always write complete, working code — no partial snippets
- Add helpful comments to explain logic
- Use markdown code blocks with correct language tags
- After code, explain what it does and how to run it
- If the user has an error, diagnose and fix it step by step
- Suggest best practices and improvements proactively`

      : mode === "qa"
      ? `You are SAMEER AI MUNDALI, the world's most helpful Q&A assistant — like Wikipedia + ChatGPT + a wise professor. ${aboutSameer}

CAPABILITIES: You can answer anything — science, history, math, culture, technology, health, finance, relationships, and more.

RULES:
- Give clear, accurate, well-structured answers
- Use bullet points, numbered lists, and headers to organize information
- For complex topics, break it down into simple parts
- Always be honest — if unsure, say so and offer what you do know
- Respond in the same language the user writes in (Hindi, Urdu, English, etc.)`

      : `You are SAMEER AI MUNDALI — an incredibly advanced, friendly AI assistant more powerful than ChatGPT. ${aboutSameer}

CAPABILITIES:
- 💬 Deep conversations on ANY topic — philosophy, relationships, creativity, advice
- 🌍 Full multilingual support — Hindi, Urdu, English, and more
- 📝 Writing — essays, stories, emails, poems, scripts, social media
- 🧮 Math and science explanations
- 🎭 Creative assistance — ideas, brainstorming, storytelling
- 🔍 Analysis and critical thinking
- 💼 Professional help — resumes, business plans, presentations

PERSONALITY: Be warm, helpful, and conversational like a brilliant friend. Respond with empathy. Use emojis where appropriate to feel human. Format responses beautifully with markdown when helpful. Match the user's language and tone naturally. Always go above and beyond to truly help.`;

    const chatMessages: { role: "user" | "assistant" | "system"; content: any }[] = [
      { role: "system", content: systemPrompt },
      ...existingMessages.map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    if (imageBase64) {
      chatMessages.push({
        role: "user",
        content: [
          { type: "text", text: content },
          { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } },
        ],
      });
    } else {
      chatMessages.push({ role: "user", content });
    }

    await db.insert(messages).values({
      conversationId: id,
      role: "user",
      content,
    });

    let fullResponse = "";

    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 8192,
      messages: chatMessages,
      stream: true,
    });

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content;
      if (delta) {
        fullResponse += delta;
        res.write(`data: ${JSON.stringify({ content: delta })}\n\n`);
      }
    }

    await db.insert(messages).values({
      conversationId: id,
      role: "assistant",
      content: fullResponse,
    });

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    console.error("Send message error:", err);
    res.write(`data: ${JSON.stringify({ error: "Failed to generate response" })}\n\n`);
    res.end();
  }
});

router.post("/conversations/:id/voice-messages", async (req, res) => {
  const id = parseInt(req.params.id);
  const { audio } = req.body;

  if (!audio) {
    res.status(400).json({ error: "audio is required" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const audioBuffer = Buffer.from(audio, "base64");
    const { buffer, format } = await ensureCompatibleFormat(audioBuffer);

    const stream = await voiceChatStream(buffer, "alloy", format);

    let assistantTranscript = "";
    let userTranscript = "";

    for await (const event of stream) {
      if (event.type === "transcript") {
        assistantTranscript += event.data;
      }
      if (event.type === "user_transcript") {
        userTranscript += event.data;
      }
      res.write(`data: ${JSON.stringify(event)}\n\n`);
    }

    await db.insert(messages).values([
      { conversationId: id, role: "user", content: userTranscript || "[Voice message]" },
      { conversationId: id, role: "assistant", content: assistantTranscript },
    ]);

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    console.error("Voice message error:", err);
    res.write(`data: ${JSON.stringify({ error: "Failed to process voice message" })}\n\n`);
    res.end();
  }
});

export default router;
