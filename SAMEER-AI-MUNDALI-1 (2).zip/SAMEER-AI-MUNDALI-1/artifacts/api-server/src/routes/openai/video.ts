import { Router } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";

const router = Router();

router.post("/generate-video-frames", async (req, res) => {
  const { prompt, style, frameCount = 6 } = req.body;

  if (!prompt) {
    res.status(400).json({ error: "prompt is required" });
    return;
  }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  try {
    const styleGuide = style === "anime"
      ? "anime style, vibrant colors, manga art, Studio Ghibli inspired, detailed anime illustration"
      : style === "realistic"
      ? "photorealistic, cinematic, high detail, 8K ultra realistic photography"
      : style === "cartoon"
      ? "cartoon style, colorful, fun, animated, pixar style 3D animation"
      : style === "fantasy"
      ? "epic fantasy art, magical, mystical, ethereal glow, concept art, digital painting"
      : "cinematic, high quality, detailed, beautiful";

    const scriptRes = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 1500,
      messages: [{
        role: "system",
        content: "You are a video director. Create exactly the requested number of sequential video frame descriptions. Each frame should flow naturally into the next like a movie scene. Output ONLY a JSON array of frame descriptions, no other text."
      }, {
        role: "user",
        content: `Create ${frameCount} sequential video frame descriptions for: "${prompt}". Style: ${styleGuide}. Make each frame description detailed and visual, like a movie scene. Return ONLY valid JSON array: ["frame1 description", "frame2 description", ...]`
      }],
    });

    const scriptText = scriptRes.choices[0]?.message?.content || "[]";
    let frameDescriptions: string[] = [];

    try {
      const jsonMatch = scriptText.match(/\[[\s\S]*\]/);
      frameDescriptions = JSON.parse(jsonMatch?.[0] || "[]");
    } catch {
      frameDescriptions = Array.from({ length: frameCount }, (_, i) =>
        `${prompt}, scene ${i + 1}, ${styleGuide}`
      );
    }

    res.write(`data: ${JSON.stringify({ type: "script", total: frameDescriptions.length })}\n\n`);

    const frames: string[] = [];

    for (let i = 0; i < frameDescriptions.length; i++) {
      const framePrompt = `${frameDescriptions[i]}, ${styleGuide}, high quality, no text, no watermarks`;
      try {
        const buffer = await generateImageBuffer(framePrompt, "1024x1024");
        const b64 = buffer.toString("base64");
        frames.push(b64);
        res.write(`data: ${JSON.stringify({ type: "frame", index: i, total: frameDescriptions.length, b64_json: b64, description: frameDescriptions[i] })}\n\n`);
      } catch (err) {
        console.error(`Frame ${i} generation failed:`, err);
        res.write(`data: ${JSON.stringify({ type: "frame_error", index: i })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ type: "done", totalFrames: frames.length })}\n\n`);
    res.end();
  } catch (err) {
    console.error("Video generation error:", err);
    res.write(`data: ${JSON.stringify({ type: "error", message: "Video generation failed" })}\n\n`);
    res.end();
  }
});

export default router;
