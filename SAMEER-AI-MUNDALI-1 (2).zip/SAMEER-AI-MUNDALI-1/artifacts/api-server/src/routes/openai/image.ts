import { Router } from "express";
import { generateImageBuffer } from "@workspace/integrations-openai-ai-server/image";
import { textToSpeech } from "@workspace/integrations-openai-ai-server/audio";

const router = Router();

router.post("/generate-image", async (req, res) => {
  const { prompt, size } = req.body;

  if (!prompt) {
    res.status(400).json({ error: "prompt is required" });
    return;
  }

  try {
    const validSize = (["1024x1024", "512x512", "256x256"] as const).includes(size)
      ? size
      : "1024x1024";
    const buffer = await generateImageBuffer(prompt, validSize);
    res.json({ b64_json: buffer.toString("base64") });
  } catch (err) {
    console.error("Image generation error:", err);
    res.status(500).json({ error: "Failed to generate image" });
  }
});

router.post("/tts", async (req, res) => {
  const { text, voice } = req.body;

  if (!text) {
    res.status(400).json({ error: "text is required" });
    return;
  }

  try {
    const validVoice = (["alloy", "echo", "fable", "onyx", "nova", "shimmer"] as const).includes(voice)
      ? voice as "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer"
      : "nova";
    const audioBuffer = await textToSpeech(text, validVoice, "mp3");
    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Content-Length", audioBuffer.length);
    res.send(audioBuffer);
  } catch (err) {
    console.error("TTS error:", err);
    res.status(500).json({ error: "Failed to generate speech" });
  }
});

export default router;
