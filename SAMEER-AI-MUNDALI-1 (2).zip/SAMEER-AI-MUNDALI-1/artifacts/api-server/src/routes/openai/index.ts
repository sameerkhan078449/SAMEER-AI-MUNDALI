import { Router, type IRouter } from "express";
import conversationsRouter from "./conversations";
import imageRouter from "./image";
import videoRouter from "./video";

const router: IRouter = Router();

router.use("/openai", conversationsRouter);
router.use("/openai", imageRouter);
router.use("/openai", videoRouter);

export default router;
