# SAMEER AI MUNDALI Workspace

## Overview

Full-stack AI chat platform called "SAMEER AI MUNDALI" — a comprehensive AI assistant with real-time chat, voice interaction, image generation, and more.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend framework**: React + Vite (Tailwind CSS, shadcn/ui)
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **AI**: OpenAI via Replit AI Integrations (no API key needed)
- **Auth**: Replit Auth (OpenID Connect / PKCE)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── api-server/         # Express API server
│   └── sameer-ai/          # React + Vite frontend (at /)
├── lib/
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   ├── db/                 # Drizzle ORM schema + DB connection
│   ├── integrations-openai-ai-server/  # OpenAI server-side helpers
│   ├── integrations-openai-ai-react/   # OpenAI React hooks (voice)
│   └── replit-auth-web/    # Replit Auth browser hooks
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Key Features

- **AI Chat**: Real-time streaming text chat with GPT-5.2, context memory, code/Q&A/chat modes
- **Voice**: Voice input (speech-to-text) and voice output (text-to-speech)  
- **Image Generation**: AI image generation with gpt-image-1
- **Image Analysis**: Upload images and ask questions about them
- **Auth**: Replit Auth with login/logout/profile
- **Conversations**: Create, rename, delete, search chat history
- **Dark/Light Mode**: Theme toggle with system preference support
- **Responsive**: Mobile-friendly sidebar navigation

## API Routes

All routes prefixed with `/api`:
- `GET /healthz` — Health check
- `GET /auth/user` — Current user
- `GET /login` — OIDC login redirect
- `GET /callback` — OIDC callback
- `GET /logout` — Logout
- `GET /openai/conversations` — List conversations
- `POST /openai/conversations` — Create conversation
- `GET /openai/conversations/:id` — Get conversation with messages
- `PATCH /openai/conversations/:id` — Rename conversation
- `DELETE /openai/conversations/:id` — Delete conversation
- `GET /openai/conversations/:id/messages` — List messages
- `POST /openai/conversations/:id/messages` — Send message (SSE stream)
- `POST /openai/conversations/:id/voice-messages` — Voice message (SSE stream)
- `POST /openai/generate-image` — Generate image

## Database Schema

- `users_table` — Auth users (from replit-auth)
- `sessions_table` — Auth sessions  
- `conversations` — Chat conversations (id, title, userId, createdAt)
- `messages` — Chat messages (id, conversationId, role, content, createdAt)

## Development

```bash
# Start API server
pnpm --filter @workspace/api-server run dev

# Start frontend
pnpm --filter @workspace/sameer-ai run dev

# Update OpenAPI → regenerate types
pnpm --filter @workspace/api-spec run codegen

# Push DB schema
pnpm --filter @workspace/db run push
```
